package maventest;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SignUp {

    WebDriver driver = new ChromeDriver();
    @Test
    public void signinstestingpasscase() {
        driver.navigate().to("https://app.oberlo.com/register");
        driver.manage().window().maximize();
        WebElement myElement = driver.findElement(By.name("Your email"));
        String js = "arguments[0].setAttribute('value','"+"mehsannjadoon786@gmail.com"+"')";
        ((JavascriptExecutor) driver).executeScript(js, myElement);
        WebElement myElement4 = driver.findElement(By.id("password"));
        String js4 = "arguments[0].setAttribute('value','"+"ehsan123"+"')";
        ((JavascriptExecutor) driver).executeScript(js4, myElement4);
        WebElement ele = driver.findElement(By.xpath("//button[contains(.,'Sign up for Free')]"));
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", ele);

    }
    @Test
    public void signinstestingfailcase() {
        driver.navigate().to("https://app.oberlo.com/register");
        driver.manage().window().maximize();
        WebElement myElement = driver.findElement(By.name("Your email"));
        String js = "arguments[0].setAttribute('value','"+"mehsanjadoon786@zaq.com"+"')";
        ((JavascriptExecutor) driver).executeScript(js, myElement);
        WebElement myElement4 = driver.findElement(By.id("Password"));
        String js4 = "arguments[0].setAttribute('value','"+"ehsan123"+"')";
        ((JavascriptExecutor) driver).executeScript(js4, myElement4);
        WebElement ele = driver.findElement(By.xpath("//button[contains(.,'Sign up for Free')]"));
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", ele);
    }
}
