package maventest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class M_Test {
    @Test
    public  void  startwebdrver(){
        WebDriver driver = new ChromeDriver();
        driver.navigate().to("https://app.oberlo.com");
        Assertions.assertTrue(driver.getTitle().startsWith("Login to E-COHERENCE"),
                "Tittle should start differently");
        driver.close();
    }
}