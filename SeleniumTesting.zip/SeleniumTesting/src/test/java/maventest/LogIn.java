package maventest;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LogIn {
    WebDriver driver,
    driver = new ChromeDriver();
    @Test
    public void signinstestingpasscase(){
        driver.navigate().to("https://app.oberlo.com/login");
        driver.manage().window().maximize();
        WebElement myElement = driver.findElement(By.name("Email"));
        String js = "arguments[0].setAttribute('value','"+"mehsanjadoon722@gmail.com"+"')";
        ((JavascriptExecutor) driver).executeScript(js, myElement);
        WebElement myElement1 = driver.findElement(By.name("Password"));
        String js1 = "arguments[0].setAttribute('value','"+"ehsan123"+"')";
        ((JavascriptExecutor) driver).executeScript(js1, myElement1);
        WebElement ele = driver.findElement(By.name("Log In")));
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", ele);
        if(driver.getTitle().contains("dashboard"))
            System.out.println("Matched");
        else
            System.out.println("not match");
    }

    @Test
    public void signinstestingfailcase(){
        driver.navigate().to("https://app.oberlo.com/login");
        driver.manage().window().maximize();
        WebElement myElement = driver.findElement(By.name("Email"));
        String js = "arguments[0].setAttribute('value','"+"mehsanjadoon722@gmail.com+"')";
        ((JavascriptExecutor) driver).executeScript(js, myElement);
        WebElement myElement1 = driver.findElement(By.name("Password"));
        String js1 = "arguments[0].setAttribute('value','"+"ehsan1123"+"')";
        ((JavascriptExecutor) driver).executeScript(js1, myElement1);
       WebElement ele = driver.findElement(By.id("btn_StudentSignIn"));
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", ele);
        if(driver.getTitle().contains("dashboard"))
            System.out.println("Matched");
        else
            System.out.println("not match");
    }
}