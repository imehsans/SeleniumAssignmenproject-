# Selenium Testing
Assignment Number 3 on selenium testing for Take any website for signup and login, make automated test cases in selenium. Two for signup and two for log in.  Remember to pass one test case for signup and login and another test case to be failed for signup and login.

